public class Main2 {

    public static void main(String[] args) {
        Car car = new Car("cerola", 120, 4);
        System.out.println("Car Details:");
        car.showDetails();

        System.out.println();

        Bike bike = new Bike("Honda", 150, "Full-Face");
        System.out.println("Bike Details:");
        bike.showDetails();
    }
}

