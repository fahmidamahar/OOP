
class GraduateStudent extends Student {
  String researchTopic;

  GraduateStudent(String n, int a, String id, String topic) {
    super(n, a, id);
    researchTopic = topic;
  }

  void displayDetails() {
    displayStudentInfo();
    System.out.println("Research Topic: " + researchTopic);
  }
}
