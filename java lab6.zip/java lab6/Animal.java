class Animal{
String name;
int age;
public void makeSound(){

System.out.println("making sound....");


}
}