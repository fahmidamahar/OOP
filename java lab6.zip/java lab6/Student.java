class Student extends Person {
  String studentID;

  Student(String n, int a, String id) {
    super(n, a);
    studentID = id;
  }

  void displayStudentInfo() {
    displayInfo();
    System.out.println("Student ID: " + studentID);
  }
}

// 