
public class Main1 {
  public static void main(String[] args) {
    GraduateStudent gs = new GraduateStudent("fahmida", 20, "f24mmg43", "programmingAI");
    gs.displayDetails();
  }
}

