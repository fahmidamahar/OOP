 class Rectangle extends Shape {
 @Override
    void draw() {
        System.out.println("Drawing a Rectangle");
    }
}
