public class Main {
    public static void main(String[] args) {

        Dog myDog = new Dog();
       myDog.name = "mono";
       myDog.age = 5;
           
        System.out.println("Name: " + myDog.name);
        System.out.println("Age: " + myDog.age);
        myDog.makeSound();
    }
}


