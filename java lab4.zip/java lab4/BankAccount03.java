public class BankAccount03 {
    String accountNumber;
    double balance;

    public BankAccount03(double balance) {
        this.balance = balance;
    }

    void displayBalance() {
        System.out.println("Balance: " + balance);
    }

    void withdraw(double amount) {
        if (amount <= balance) {
            balance = balance - amount;
        } else {
            System.out.println("Withdraw amount is larger than balance.");
        }
    }

    void deposit(double amount) {
        balance = balance + amount;
    }

    public static void main(String[] args) {
        BankAccount03 acc1 = new BankAccount03(1000.0);
        BankAccount03 acc2 = new BankAccount03(500.0);

        acc1.displayBalance();
        acc2.displayBalance();

        acc1.withdraw(200);
        acc1.displayBalance();
    }
}


