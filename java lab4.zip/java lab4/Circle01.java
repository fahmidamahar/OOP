public class Circle01 {
    String color;
    double radius;

    public Circle01(String color, double radius) {
        this.color = color;
        this.radius = radius;
    }

    public void calculateArea() {
        System.out.println("Area: " + 3.14 * radius * radius);
    }

    public static void main(String[] args) {
        Circle01  greenCircle = new  Circle01("green", 10.0);
        Circle01  redCircle = new  Circle01("red", 15.5);

        System.out.println("Red Circle Radius: " + redCircle.radius);
        System.out.println("Green Circle Radius: " + greenCircle.radius);

        redCircle.calculateArea();
        greenCircle.calculateArea();
    }
}
