class cat extends Animal {
void makeSound(){
System.out.println("cat meows");
}
}