 public class Main {
public static void main(String [] args){
Calculator c1 = new Calculator();
System.out.println(c1.add(5,3));
System.out.println(c1.add(2.5, 3.7));
System.out.println(c1.add("Hello",  "word"));

}
}