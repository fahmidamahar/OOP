class Bank{
float getInterestRate(){
return 0;
}
}