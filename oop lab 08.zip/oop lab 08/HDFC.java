class HDFC extends Bank{
 float getInterestRate(){
return 6.8f;
}
}