 public class TestBank{

public static void main(String [] args){
Bank sbi = new SBI();
Bank icici = new ICICI();
Bank hdfc = new HDFC();
System.out.println("SBI interset:" + sbi.getInterestRate());
System.out.println("ICICI interset:" + icici.getInterestRate());
System.out.println("HDFC interset:" + hdfc.getInterestRate());
}
}