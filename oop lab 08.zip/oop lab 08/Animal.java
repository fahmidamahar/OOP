 class Animal {
void  makeSound(){
System.out.println("Animal makeSound");
}
}