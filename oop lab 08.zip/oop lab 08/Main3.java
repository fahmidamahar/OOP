class Main3 {
public static void main (String [] args){
Animal myAnimal = new Animal();
 
Animal myDog = new Dog(); 
Animal mycat = new cat(); 
myAnimal.makeSound();   
myDog.makeSound();     
mycat.makeSound(); 
}
}   