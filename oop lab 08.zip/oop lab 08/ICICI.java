class ICICI extends Bank{
 float getInterestRate(){
return 8.2f;
}
}