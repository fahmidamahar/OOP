class SBI extends Bank{
 float getInterestRate(){
return 7.5f;
}
}