import java.util.Scanner;

public class speedc{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double milesPerHour;

        System.out.println("Enter speed in miles per hour: ");
        milesPerHour = scanner.nextDouble();

        double kilometersPerHour = milesPerHour * 1.60934;

        System.out.println(milesPerHour + " miles per hour is equal to " + kilometersPerHour + " kilometers per hour");
    }
}