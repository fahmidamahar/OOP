import java.util.Scanner;

public class Currency{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the value of dollars: ");
        double dollars = scanner.nextDouble();

        double rupees = dollars * 280.41; // 1 USD = 280.41 INR (approx)

        System.out.println("Value in rupees: " + rupees);
    }
}