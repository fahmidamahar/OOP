public class stars{
public static void main(String[] arguments){
System.out.println("*************");
System.out.println("*           *");   
System.out.println("*           *");
System.out.println("*           *");
System.out.println("*************");
}
}