

public class lab{
public static void main (String arguments[]){
System.out.println("this is long String that is the"+"concatention of two shoter String.");
System.out.println("the first computer was invented about"+55+"syears ago.");
System.out.println("8 puls 5 is" + 8 + 5);
System.out.println("8 puls 5 is" +(8 + 5));
System.out.println("8 + 5 "+"equal 8 puls 5.");

}
}