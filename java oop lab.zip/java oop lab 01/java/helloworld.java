public class helloworld
{
public static void main (String arguments[])
{
System.out.println("hello world");

}
}