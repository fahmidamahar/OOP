public class Mathsexpression{
public static void main(String[] arguments){
int result  = (10 + 5) * (4 - 6) /4;
 System.out.println("result:" + result);
}
}