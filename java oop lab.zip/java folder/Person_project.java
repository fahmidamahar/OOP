 class Person_project{

    private String name;
     private int  age;
     private double id;  
    private String dob;

    public Person_project(String name, int age, double id, String dob) {
        this.name = name;
        this.age = age;
        this.id = id;
        this.dob = dob;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age){
            this.age = age;
   }
   public double getId(){
   return id;
   }
   public void setId(double id){
   this.id = id;
   }
    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void displayInfo() {
    System.out.println("Name: " + name + ", Age: " + age + ", Id: " + id + ", DOB: " + dob);


    }
}


