class Dog extends Animal{
private int size;
private String breed;

Dog(int age, String species, int size, String breed);
Super(age,species,size,breed);
this.size = size;
this.breed = breed;
}

public void makeSound(){
suber.makeSound();
System.out.println("age:" + Super.age);
System.out.println("species:" + Super.species);

System.out.println("size:" + Super.size);

System.out.println("Breed:" + Super.breed);


}
}


