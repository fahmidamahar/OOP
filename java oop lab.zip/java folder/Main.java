class Main{
public static void main (String args){
Dog d1 = new Dog(20, "species", 40, "breed");
d1.makeSound();

Dog d2 = new Dog(40,"breed");
d2.makeSound();
}
}