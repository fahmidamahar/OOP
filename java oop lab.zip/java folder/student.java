public class student extends person {
     int sid;
    String grade;

    public student(String name, int age, String gender, int id, String contact, int sid, String grade) {
        super(name, age, gender, id, contact);
        this.sid = sid;
        this.grade = grade;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("student ID: " + sid);
        System.out.println("Grade: " + grade);
    }
}


