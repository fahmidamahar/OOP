class mains {
public class StudentInformationSystem {
    public static void main(String[] args) {
        
        Student student1 = new Student("fahmida","20","0.50", "2004-03-15", "S123", "Computer Science");

   
        student1.displayInfo();
    }
}
}