class Animal{
private int age;
private String species;

Animal(int age, String species);
this.age = age;
this.species = species;
}

public int getAge(){
return age;
}
public void setAge(int age){
this.age = age;
}
public String getSpecies(){
return species;
}
public void setSecies(String species){
this.species = species;
}
public void makeSound(){
System.out.println("age:" +age);
System.out.println("species:" +species);

}