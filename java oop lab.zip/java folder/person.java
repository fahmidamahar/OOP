public class person {
     String name;
    int age;
    String gender;
     int id;
     String contact;

    public person(String name, int age, String gender, int id, String contact) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.id = id;
        this.contact = contact;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("ID: " + id);
        System.out.println("Contact: " + contact);
    }
}

