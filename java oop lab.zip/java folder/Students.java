public class Students extends Person_project {
    private String studentsId;
    private String course;

    public Students(String name, int age, double id, String dob, String studentsId, String course) {
        super(name, age, id, dob);
        this.studentsId = studentsId;
        this.course = course;
    }

    public String getStudentsId() {
        return studentsId;
    }

    public void setStudentsId(String studentsId) {
        this.studentsId = studentsId;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Students ID: " + studentsId + ", Course: " + course);
    }


public class StudentsInformationSystem {
    public static void main(String[] args) {
        Students student1 = new Students("Fahmida", 20, 0.50, "2004-03-15", "S123", "Computer Science");
        student1.displayInfo();
    }
}
}

