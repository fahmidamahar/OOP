public class Circle02 {
    String color;
    double radius;

    public Circle02(String color, double radius) {
        this.color = color;
        this.radius = radius;
    }

    public double calculateArea() {
        return 3.14 * radius * radius;
    }

    public static void main(String[] args) {
        Circle02 greenCircle = new Circle02 ("green", 10.0);
        Circle02 redCircle = new Circle02 ("red", 15.5);

        System.out.println(redCircle.radius);
        System.out.println(greenCircle.radius);

        System.out.println("Red Circle Area: " + redCircle.calculateArea());
        System.out.println("Green Circle Area: " + greenCircle.calculateArea());
    }
}
