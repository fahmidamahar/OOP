public class Employee04 {
    String name;
    String address;
    int yearOfJoining;

    public Employee04(String name, String address, int yearOfJoining) {
        this.name = name;
        this.address = address;
        this.yearOfJoining = yearOfJoining;
    }

    public void display() {
        System.out.println(name + "\t" + yearOfJoining + "\t" + address);
    }


    public static void main(String[] args) {

        Employee04 robert = new Employee04("Robert", "WallsStreat", 1994);

        Employee04 sam = new Employee04("Sam", "WallsStreat", 2000);

        Employee04 john = new Employee04("John", "WallsStreat", 1999);

        System.out.println("Name\tYear of Joining\tAddress");

        robert.display();
        sam.display();
        john.display();
    }
}
