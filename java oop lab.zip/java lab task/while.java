public class while{
 public static void main(String [] args){

int i = 1;
while(i <= 21){

if(i % 2 != 0){
System.out.println(i);
System.out.println("Enter the odd number");
}
i++;
}
}
}

