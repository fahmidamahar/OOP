public class students05 {
String name;
String id;
double[] grade = new double[5];
students05(String name, String id, double grade[]){
this.name = name;
this.id = id;
this.grade = grade;

}
void gradeAvg(){
double sum = 0;
for(double val:grade){
sum +=val;
}
System.out.println("Avg:"+sum/grade.length);
}
public static void main(String[] args){
double[] gs1 = {1,2,3,4,5};
students05 s1 = new students05("fahmida","123abc",gs1);
s1.gradeAvg();
}
}





























   