public class Calculator {

public int add(int a, int b){
return a + b;
}
public int add(int a, int c){
return a + c;
}
public int add(double a, double b){
return a + b;
} 
    public static void main(String[] args) {

   Caluclator caluclator = new Caluclator();
  System.out.println(caluclator.add(1,2));

 System.out.println(caluclator.add(1,3));

System.out.println(caluclator.add(1.5, 2.6));


}
}

    