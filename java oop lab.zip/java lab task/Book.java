
public class Book {
    String title;
    String author;
    boolean isAvailable;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public void borrowBook() {
        if (isAvailable) {
            System.out.println("Book is borrowed");
            isAvailable = false;
        } else {
            System.out.println("Book is not available");
        }
    }

    public void displayDetails() {
        System.out.println("Book title: " + title);
        System.out.println("Book author: " + author);
        System.out.println("Book is available: " + isAvailable);
    }

    public void returnBook() {
        if (!isAvailable) {
            System.out.println("Book is returned");
            isAvailable = true;
        } else {
            System.out.println("Book is already available");
        }
    }

    public static void main(String[] args) {
        Book b1 = new Book("Harry potter", "j.k Rowling");
        b1.displayDetails();
        b1.borrowBook();
        b1.displayDetails();
        b1.returnBook();
        b1.displayDetails();
    }
}
