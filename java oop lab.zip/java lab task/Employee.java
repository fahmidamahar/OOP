public class Employee {
    String name;
    String empID;
    int salary;

    public Employee(String name, String empID, int salary) {
        this.name = name;
        this.empID = empID;
        this.salary = salary;
    }

    public void increaseSalary(int amount) {
        this.salary += amount;
    }

    public void calculateAnnualSalary() {
        System.out.println("The annual salary is: " + (salary * 12));
    }

    public void displayDetails() {
        System.out.println("Employee Name: " + name);
        System.out.println("Employee ID: " + empID);
        System.out.println("Employee Salary: " + salary);
    }

    public static void main(String[] args) {
        Employee e1 = new Employee("Fahmida", "2345678", 2000);
        e1.increaseSalary(2000);
        e1.calculateAnnualSalary();
        e1.displayDetails();
    }
}





































/*public class Book {
    String title;
    String author;
    boolean isAvailable;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public void borrowBook() {
        if (isAvailable) {
            System.out.println("Book is borrowed");
            isAvailable = false;
        } else {
            System.out.println("Book is not available");
        }
    }

    public void displayDetails() {
        System.out.println("Book title: " + title);
        System.out.println("Book author: " + author);
        System.out.println("Book is available: " + isAvailable);
    }

    public void returnBook() {
        if (!isAvailable) {
            System.out.println("Book is returned");
            isAvailable = true;
        } else {
            System.out.println("Book is already available");
        }
    }

    public static void main(String[] args) {
        Book b1 = new Book("Harry potter", "j.k Rowling");
        b1.displayDetails();
        b1.borrowBook();
        b1.displayDetails();
        b1.returnBook();
        b1.displayDetails();
    }
}*/
