class Main {

public static void main (String args){

student s1 = new student("fahmida", 43, "female", 102, "0123342", 103, "pass");

s1.displayInfo();

student s2 = new student(433, 400);
s2.displayInfo();

}

}