class students {
    private String name;
    private double id;
    private int age;

    public students(String name, int age,double id) {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setId(double id) {
        this.id = id;
    }

    public static void main(String[] args) {

        students student = new students("fahmida", 20, 0.43);

        System.out.println("Name: " + student.getName());
        System.out.println("Age: " + student.getAge());
        System.out.println("Id: " + student.getId());
    }
}


