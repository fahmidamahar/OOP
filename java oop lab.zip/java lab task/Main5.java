 public class Main5{
 public static void main(String [] args){
 int[][] matrix = {
     {12,13,14},
     {15,16,18},
     {19,20,21}
};
int i = 0, j;
System.out.println("print the matrix");
do{
j = 0;
do{
System.out.print(matrix[i][j] + " ");
j++;
}
while(j < 3);
System.out.println();
i++;
}
while(i < 3);
}
}