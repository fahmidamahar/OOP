public class Demo{
void show(){
System.out.println("this is parent class Demo");
}
}
class childDemo extends Demo{
@Override
void show(){
System.out.println("this is the child class chilDdemo");
}
}
public class Main{
public static void main(String [] args){
Demo obj1 = new Demo();
obj1.show();
Demo obj2 = new Demo();
obj2.show();
}
}
