public class cal{
public int add(int a, int b){
return a+b;
}
public float add(float a, float c){
return a+c;
}
public double add(double a, double b){
return a+b;
}
public static void main(String [] args){
 cal cal = new cal();

System.out.println(cal.add(1,2));

System.out.println(cal.add(1.3,3.4));

System.out.println(cal.add(1.2,2.1));
}
}