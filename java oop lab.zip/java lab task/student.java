class student extends person{
int Sid;
String Grade;

student(String name, int age, String gender, int id, String contant, int Sid, String Grade){
super(name, age, gender, id, contant);
this.Sid = Sid;
this.Grade = Grade;
}
void displayInfo(){

System.out.println("name:" + super.name);

System.out.println("age:" + super.age);

System.out.println("gender:" + super.gender);

System.out.println("id:" + super.id);

System.out.println("contant:" + super.contant);

System.out.println("Sid:" + super.Sid);

System.out.println("Grade:" + super.Grade);

}
}
