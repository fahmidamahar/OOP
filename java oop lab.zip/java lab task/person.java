class person{
String name;
int age;
String gender;
int id;
String contant;
person (String name, int age,String gender, int id, String contant){
this.name = name;
this.age = age;
this.gender = gender;
this.id = id;
this.contant = contant;
}
void displayInfo(){

System.out.println("name :"+ name);

System.out.println("age :"+ age);

System.out.println("gender :"+ gender);

System.out.println("id :"+ id); 

System.out.println("contant :"+ contant);
}
}	 