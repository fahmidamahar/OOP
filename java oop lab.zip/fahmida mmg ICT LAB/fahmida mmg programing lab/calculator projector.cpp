#include <iostream>
#include <math.h>
using namespace std;
int main(){
cout<<"\n\t----------------------------------------------------------\n";
cout<<"\t                 CALCULATER                                  \n";                 
cout<<"\t-------------------------------------------------------------\n";
cout<<"\t1:addition\t\t"<<"8:sin"<<endl;
cout<<"\t2:subtraction\t\t"<<"9:cos"<<endl;
cout<<"\t3:multiplication\t"<<"10:tan"<<endl;
cout<<"\t4:division\t\t"<<"11:inverse of sin"<<endl;
cout<<"\t5:exponent\t\t"<<"12:inverse of cos"<<endl;
cout<<"\t6:square\t\t"<<"13:inverse of tan"<<endl;
cout<<"\t7:log\t\t\t  "<<"14:exist"<<endl;

float x,y;
float IP=3.1415;
int choice;
  do{
	cout<<"\n\tEnter the function that you went to perform:";
	cin>>choice;
	switch(choice){
case 1:
	cout<<"\nEnter 1St number : ";
	cin	>>x;
	cout<<"Enter 2nd number : ";
	cin>>y;
	cout<<"\nResult = "<<x+y<<endl;
	break;

	
case 2:
	cout<<"\nEnter 1St number : ";
	cin	>>x;
	cout<<"Enter 2nd number : ";
	cin>>y;
	cout<<"\nResult = "<<x-y<<endl;
	break;
case 3:
	cout<<"\nEnter 1St number : ";
	cin	>>x;
	cout<<"Enter 2nd number : ";
	cin>>y;
	cout<<"\nResult = "<<x*y<<endl;
	break;
case 4:
	cout<<"\nEnter 1St number : ";
	cin	>>x;
	cout<<"Enter 2nd number : ";
	cin>>y;
	cout<<"\nResult = "<<x/y<<endl;
	break;
case 5:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"Enter the Exponent : ";
	cin>>y;
	cout<<"\nResult = "<<pow(x,y)<<endl;
	break;
case 6:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<sqrt(x)<<endl;
	break;
case 7:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<log10(x)<<endl;
	break;
case 8:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<sin(x)<<endl;
	break;
case 9:
	cout<<"\nEnter the number : ";
	cin>>x;
	cout<<"\nResult = "<<cos(x)<<endl;
	break;
case 10:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<tan(x)<<endl;
	break;
case 11:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<asin(x)*180.0 / IP<<endl;
	break;
case 12:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<acos(x)*180.0/ IP<<endl;
	break;
case 13:
	cout<<"\nEnter the number : ";
	cin	>>x;
	cout<<"\nResult = "<<atan(x)*180.0 /IP<<endl;
	break;
case 14:
	break;
	default:
		cout<<"\nWrong input\n";
	break;
	}
}while(choice != 14);
return 0;
}

