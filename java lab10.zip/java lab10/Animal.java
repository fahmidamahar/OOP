 abstract class Animal {
public abstract void makeSound();

public void  eat(){

System.out.print("Animal a eating");
}
}
