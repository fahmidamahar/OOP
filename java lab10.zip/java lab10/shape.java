abstract class shape {

 abstract double area();

interface printable {

void print();
}
}