class car implements vehicle {

public void start(){

System.out.println("car stating");
}

public void stop(){

System.out.println("car stoping");

}

} 

