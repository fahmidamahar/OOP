interface vehicle {

public void start();

public void stop();


}