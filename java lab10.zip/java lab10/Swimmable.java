interface Swimmable {
void swim();
}