public class main4 {
public static void main(String [] args){
Duck d1  = new Duck();
d1.fly();
d1.swim();
}
}