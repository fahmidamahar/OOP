class main1 {
public static void main(String [] args){

vehicle c1 = new car();

vehicle b1 = new Bike();



c1.start();
c1.stop();

b1.start();
b1.stop();



}
}