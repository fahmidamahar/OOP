class main3 {
public static void main(String [] args) {

Rectangle r1 = new Rectangle(10,5);

System.out.println("Area: " + r1.area());
r1.area();

}
}