class Bike implements vehicle {
public void start(){

System.out.println("Bike stating");
}
public void stop(){

System.out.println("Bike stoping");


}
}