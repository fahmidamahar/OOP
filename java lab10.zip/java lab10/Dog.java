class Dog extends Animal{

public void makSound(){

System.out.println("Dog is a borking");
}
}