class cat extends Animal{

public void makSound(){


System.out.println(" cat is mewo ");
}
}