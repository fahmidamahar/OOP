class Rectangle extends shape implements Printable {

double width, height;

 Rectangle(double w, double h){

 width = w;

 height = h;
}
@Override
double area(){

return width*height;
} 
@Override
public void print(){
System.out.println("printing rectangle");
}
}