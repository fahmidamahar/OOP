interface Printable {
    void print();
}
