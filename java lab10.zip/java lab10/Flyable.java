interface Flyable {
void fly();
}
 