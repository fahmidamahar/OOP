#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
using namespace std;   
struct product {
    string name;
    int product_ids;
    float price;
    int quantity;
};

product details[100];
string username;
string password;
int key;
float sale = 0;
int quantity;
int total = 0;
string name = "project_data.txt";

void create_file(string name) {
    fstream file;
    file.open(name, ios::out);
    file.close();
}

void write_file(string name, product details[]) {
    cout << "\n\tIDs\t\tnames\t\tprice\t\t available quantity\n";
    ofstream filewrite(name, ios::app);
    for (int i = 0; i < total; i++) {
        filewrite << "\t" << details[i].product_ids << "\t\t" << details[i].name << "\t\t"
                  << details[i].price << "\t\t" << details[i].quantity << endl;
    }
}

void read_file(string name) {
    string text = "";
    ifstream fileread(name, ios::in);
    while (getline(fileread, text)) {
        cout << text << endl;
    }
}

void add_stock() {
    int choice;
    cout << "\nhow many items you want to add: ";
    cin >> choice;
    for (int i = total; i < total + choice; i++) {
        cout << "\n\tID: ";
        cin >> details[i].product_ids;
        cout << "\n\tproduct name: ";
        cin >> details[i].name;
        cout << "\n\tproduct price: ";
        cin >> details[i].price;
        cout << "\n\tquantity: ";
        cin >> details[i].quantity;
    }
    total += choice;
    cout << "stored successfully.\n";
    cout << "\npress 0 to go to main menu: ";
    cin >> key;
    system("CLS");
}

void update_stock() {
    label2:
    int id;
    cout<<"\nenter the id of item that you want to update: ";
    cin >> id;
    for (int i = 0; i < total; i++) {
        if (id == details[i].product_ids) {
            cout << "\tIDs\t\tnames\t\tprice\t\tquantity\n";
            cout << "\t" << details[i].product_ids << "\t\t" << details[i].name << "\t\t"
                 << details[i].price << "\t\t" << details[i].quantity << endl;
            cout << "\nenter p to change the price of product: ";
            cout << "\nenter q to add the quantity of product: ";
            char n;
            float temp;
            cin >> n;
            if (n == 'p') {
                cout << "Enter new price: ";
                cin >> temp;
                details[i].price = temp;
            } else if (n == 'q') {
                cout << "Add quantity: ";
                cin >> temp;
                details[i].quantity += temp;
            }
            cout << "updated successfully: ";
            cout << "\t\n_______________________________________________\n";
        }
    }
    cout << "\npress 1 to update again \n press 0 to go to main menu: ";
    cin >> key;
    if (key == 1) {
        goto label2;
    }
    system("CLS");
}

void place_order() {
    // reading product details from file!
    cout << "\n\tIDs\t\tnames\t\tprice\t\t available quantity\n";
    read_file(name);
    cout << "\t\n_____________________________________________________________________________\n";
    int id;
    float bill = 0;
    for (int i = 0; i < total; i++) {
    }
    cout << "\nwhen order is completed press 0 for bill: ";
    do {
        cout << "\nEnter the ID of the item: ";
        cin >> id;
        for (int i = 0; i < total; i++) {
            if (id == details[i].product_ids) {
                if (details[i].quantity == 0) {
                    cout << "Not available";
                } else {
                    cout << "Enter quantity: ";
                    cin >> quantity;
                    if (details[i].quantity < quantity) {
                        cout << details[i].quantity << " " << details[i].name << " available \n";
                    } else {
                        details[i].quantity -= quantity;
                        sale += details[i].price * quantity;
                        bill += details[i].price * quantity;
                        cout << details[i].product_ids << "\t\t\t" << quantity << " "
                             << details[i].name << "\t\t\t" << details[i].price << endl;
                    }
                }
            }
        }
        if (id == 0) {
            cout << "\tYour bill is " << bill << " only";
            cout << "\t\n_______________________________________________\n";
            cout << "\n\tPress 0 to go to main menu: ";
            cin >> key;
        }
    } while (id != 0);
    system("CLS");
}

void product_details() {
    // reading product details from file;
    cout << "\n\tIDs\t\tnames\t\tprice\t\t available quantity\n";
    read_file(name);
    cout << "\t\n_____________________________________________________________________________\n";
    cout << "\n\tpress 0 to go to main menu: ";
    cin >> key;
    system("CLS");
}

void record_of_sale() {
    string file_name = "sale.txt";
    cout << "\n\n\tTodays sale: " << sale << endl;
    cout << "\t\n_______________________________________________\n";
    create_file(file_name);
    ofstream writefile(file_name, ios::app);
    writefile << "today's sale =" << sale << endl;
    // reading record of sale from file;
    string text = "";
    ifstream file("sale.txt", ios::in);
    while (getline(file, text)) {
        cout << text << endl;
    }
    cout << "\npress 0 to go to main menu: ";
    cin >> key;
    system("CLS");
}

void profit_loss() {
    float invest;
    cout << "\nEnter your Invest: ";
    cin >> invest;
    if (sale > invest) {
        cout << "\n\tInvest\t\tsale\t\tprofit\n";
        cout << "\t" << invest << "\t\t" << sale << "\t\t" << sale - invest;
        cout << "\n_______________________________________________\n";
    } else if (invest > sale) {
        cout << "\n\tInvest\t\tsale\t\tLoss\n";
        cout << "\t" << invest << "\t\t" << sale << "\t\t" << invest - sale;
        cout << "\t\n_______________________________________________\n";
    }
    cout << "\npress 0 to go to main menu: ";
    cin >> key;
    system("CLS");
}

void logout() {
    char logiin;
    label1:
    string name;
    cout << "\nEnter user name: ";
    cin >> name;
    string pass;
    cout << "Enter password: ";
    cin >> pass;

    if (name == username && pass == password) {
        cout << "...........";
        return;
    } else {
        cout << "\n\nInvalid data\nTry again\n";
        goto label1;
    }
}

int main() {
    create_file(name);
    cout << "\n\tEnter data to SIGNUP" << endl;
    cout << "\n\tEnter user name: ";
    cin >> username;
    cout << "\tEnter password: ";
    cin >> password;
    // write login info in file!
    string file_name = "login_info.txt";
    create_file(file_name);
    ofstream writefile(file_name, ios::out);
    writefile << username << endl;
    writefile << password << endl;

    system("CLS");

    cout << "\n\n      \"WELCOME TO CANTEEN MANAGEMENT SYSTEM\"               ";
    label1:
    cout << "\t\n_______________________________________________\n";
    cout << "\t\n            >>MAIN MENU<<                      ";
    cout << "\t\n_______________________________________________\n";
    cout << "\n\t1.Add stock\n";
    cout << "\n\t2.Update stock\n";
    cout << "\n\t3.Product details\n";
    cout << "\n\t4.Place order\n";
    cout << "\n\t5.Record of sale\n";
    cout << "\n\t6.View profit or loss\n";
    cout << "\n\t7.Logout\n";
    int choice;
    cout << "\n>>Enter your choice: ";
    cin >> choice;
    switch (choice) {
        case 1:
            system("CLS");
            cout << "\t\n_______________________________________________\n";
            cout << "\t\n        Main Menu>>add_stock                   ";
            cout << "\t\n_______________________________________________";
            add_stock();
            write_file(name, details);
            goto label1;
            break;
        case 2:
            system("CLS");
	       cout<<"\t\n_______________________________________________\n";
	       cout<<"\t\n           Main Menu>>update stock              ";
   	       cout<<"\t\n_______________________________________________";
	       update_stock();
	       //Writing data into  file!
	       write_file(name,details);
	       goto label1;
   		break;
   	case 3:system("CLS");
	       cout<<"\t\n_______________________________________________\n";
	       cout<<"\t\n          Main Menu>>Product details           ";
   	       cout<<"\t\n_______________________________________________";
   	       product_details();
   	       goto label1;
   		break;
	case 4:system("CLS");
	       cout<<"\t\n_______________________________________________\n";
	       cout<<"\t\n              Main Menu>>Place order                    ";
   	       cout<<"\t\n_______________________________________________";
	       place_order();
	       //writing updated data into file  after placing order!
	       write_file(name,details);
	       goto label1;
   		break;
	case 5:system("CLS");
	       cout<<"\t\n_______________________________________________\n";
	       cout<<"\t\n             Main Menu>>Record of sale         ";
   	       cout<<"\t\n_______________________________________________";
	       record_of_sale();
	       goto label1;
   		break;
	case 6:system("CLS");
        	cout<<"\t\n_______________________________________________\n";
	       cout<<"\t\n          Main Menu>>Profit/Loss               ";
   	       cout<<"\t\n_______________________________________________";
   	       profit_loss();
		goto label1;
   		break;   
	case 7 :system("CLS");
	        cout<<"\t\n_______________________________________________\n";
	        cout<<"\t\n         Main Menu>>Logout                     ";
   	        cout<<"\t\n_______________________________________________";
	        exit(0);
		 break;
       default   :system("CLS");
	          cout<<"\"SELECT THE CORRECT OPTION PLEASE\"";
                  goto label1;
	        break;	   		   	   	   	   	
   }
   


return 0;
}

