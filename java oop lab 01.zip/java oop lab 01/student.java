public class Student{
    String name;
    int age;
    double gpa;
    String studentId;
    char gender;
    boolean isForeigner;

    public static void main (String arguments[]){
        Student student = new Student(); 
        student.name = "Fahmida Mhr";
        student.age = 20;
        student.gpa = 3.5;
        student.studentId = "S12345";
        student.gender = 'F';
        student.isForeigner = false;

        System.out.println("Name: " + student.name);
        System.out.println("Age: " + student.age);
        System.out.println("GPA: " + student.gpa);
        System.out.println("Student ID: " + student.studentId);
        System.out.println("Gender: " + student.gender);
        System.out.println("Is Foreigner: " + student.isForeigner);
    }
}