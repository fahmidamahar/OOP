import java.util.Scanner;
public class Task03{
public static void main(String [] args ){

Scanner scanner = new Scanner(System.in);

        int[][] rows1 = new int[2][2]; 
        int[][] coloumn2 = new int[2][2];

        System.out.println("Enter elements for matrix 1:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                rows1[i][j] = scanner.nextInt();
            }
        }

        System.out.println("Enter elements for matrix 2:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                coloumn2[i][j] = scanner.nextInt();
            }
        }


         System.out.println("Sum of matrices:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(rows1[i][j] + coloumn2[i][j] + " ");
            }
            System.out.println();
        }
    }

  }
         






















































/*public class Task02{
public static void main (String [] args){

Scanner input = new Scanner(System.in);
int [] nums = new int [10];
int sum = 0;
for(int i=0; i<nums.length; i++){
nums[i] = input.nextInt();
if(nums [i] %4 == 0){
sum += nums[i];
}
}
System.out.println("--------------output-------------"); 
System.out.println(sum);

}
}*/





















/*public class Task01{
public static void main(String [] args){
 char[] constants = {'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'};
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a character: ");
        char user_input = scanner.next().charAt(0);

        boolean isConstant = false;
       for (int i = 0; i < constants.length; i++) {
            if (user_input == constants[i]) {
                isConstant = true;
                break;
            }
        }
        if (isConstant) {
            System.out.println(user_input + " is a constant.");
        } else {
            System.out.println(user_input + " is not a constant.");
        }
        scanner.close();
    }
}*/





































/*public class Task04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       System.out.println("Enter your 6 names");
        String[] names = new String[6];

        boolean istrue = false;
        for (int i = 0; i < names.length; i++) {
            names[i] = input.nextLine();
        }
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals("ali")) {
                istrue = true;
            }
        }
        if (istrue) {
            System.out.println("available");
        } else {
            System.out.println(" is not available");
        }
       
    }
}*/


























/*public class Task06 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();

        boolean istrue = (age >= 18);
        String eligibility = (istrue) ? "You are eligible for voting." ;
        System.out.println(eligibility);
    }
}*/








































/*Scanner input = new Scanner(System.in);
int [] nums = new int [10];
int sum = 0;
for(int i=0; i<nums.length; i++){
nums[i] = input.nextInt();
if(nums [i] %4 == 0){
sum += nums[i];
}
}
System.out.println("--------------output-------------"); 
System.out.println(sum);

}
}*/


































/*Scanner scanner = new Scanner(System.in);

        int[][] rows1 = new int[2][2]; 
        int[][] coloumn2 = new int[2][2];

        System.out.println("Enter elements for matrix 1:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                rows1[i][j] = scanner.nextInt();
            }
        }

        System.out.println("Enter elements for matrix 2:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                coloumn2[i][j] = scanner.nextInt();
            }
        }


         System.out.println("Sum of matrices:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(rows1[i][j] + coloumn2[i][j] + " ");
            }
            System.out.println();
        }
    }

  }*/
         





















































       /* char[] constants = {'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'};
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a character: ");
        char user_input = scanner.next().charAt(0);

        boolean isConstant = false;
       for (int i = 0; i < constants.length; i++) {
            if (user_input == constants[i]) {
                isConstant = true;
                break;
            }
        }
        if (isConstant) {
            System.out.println(user_input + " is a constant.");
        } else {
            System.out.println(user_input + " is not a constant.");
        }
        scanner.close();
    }
}*/





































/*public class Task05{
    public static void main(String[] args) {
       
        int[][] matrix = {
            {1, 0, 0, 1},
            {1, 1, 0, 1},
            {1, 0, 1, 1},
            {1, 0, 0, 1},
           
        };

      
        System.out.println("Matrix: number of N");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
            
        }

        
        boolean check = false;
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {       
        }
                if (matrix[i][j] == 1) {
                    check = true;
                    break;
           }   
         }
        }  
    }
}*/
























































     


