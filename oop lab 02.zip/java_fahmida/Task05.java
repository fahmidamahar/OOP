import java.util.Scanner;
public class Task05 {
    public static void main(String[] args) {
      
        int[][] matrix = {
            {0, 1, 1, 0},
            {0, 0, 1, 0},
            {0, 1, 0, 0},
            {0, 1, 1, 0},
        };
        System.out.println("Matrix: number N");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
        boolean check = false;
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == 1) {
                    check = true;
                    break;
                }
            }
            if (check) {
                System.out.println("Matrix number N is print.");
                return;
            }
        }
        System.out.println("Matrix number N is print.");
    }
}


