import java.util.Scanner;

public class Task05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of rows: ");
        int rows = input.nextInt();

        System.out.print("Enter number of columns: ");
        int columns = input.nextInt();

        boolean[][] seats = new boolean[rows][columns];

        int choice;
        do {
            System.out.println("1. Display available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Available seats (false = available, true = reserved)");
                    for (int i = 0; i < rows; i++) {
                        for (int j = 0; j < columns; j++) {
                            System.out.print(seats[i][j] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 2:
                    System.out.print("Enter row number: ");
                    int row = input.nextInt();

                    System.out.print("Enter column number: ");
                    int column = input.nextInt();

                    if (row >= 0 && row < rows && column >= 0 && column < columns) {
                        if (!seats[row][column]) {
                            seats[row][column] = true;
                            System.out.println("You have reserved your seat successfully!");
                        } else {
                            System.out.println("Seat is already reserved!");
                        }
                    } else {
                        System.out.println("Invalid row or column number!");
                    }
                    break;

                case 3:
                    System.out.println("Exiting the program. Bye bye! Enjoy!");
                    break;

                default:
                    System.out.println("Invalid choice. Please enter your choice between 1-3.");
            }
        } while (choice != 3);
    }
}









