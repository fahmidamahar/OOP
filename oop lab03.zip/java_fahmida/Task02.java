import java.util.Scanner;


public class Task02 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter a string:");
        String text = input.nextLine();

        String mahar = " ";
        for(int i = text.length()-1; i>=0; i--){
            mahar = mahar + text.charAt(i);
        }
        if(mahar.equals(text)){
            System.out.println("palindrome");
        } else{
            System.out.println("not a palindrome");
        }
    }
}
