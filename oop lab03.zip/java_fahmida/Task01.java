import java.util.Scanner;

public class Task01 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter prime your number range from:");
        int num1 = input.nextInt();
        System.out.println("Enter prime your number range to:");
        int num2 = input.nextInt();

        for (int i = num1; i <= num2; i++) {
            boolean isprime = true;
            for (int j = 2; j < i; j++) {
                if (i % j == 0) {
                    isprime = false;
                    break;
                }
            }
            if (isprime) {
               System.out.println("yes prime");
             }else {
               System.out.println("not prime number");
            }
           }
       
    }
}




