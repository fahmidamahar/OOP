import java.util.Scanner;
public class Task04{
public static void main(String[] args){
int[] arr = new int[10];
int i = 0;
int j = 1;
do{
arr[i] = j * j;
j++;
i++;
}while(i <arr.length);
arr[9] = 0;
System.out.println(" Enter your array element ");
for (int a=0; a<arr.length; a++){
System.out.print(arr[a]+" ");
}
System.out.println();
int sum = 0;
i = 0;
while(i<arr.length){
if(arr[i] == 81){
break;
}
if(arr[i] %2 !=0){
sum+= arr[i];
}
i++;
}

System.out.println("sum of all odd numbers form this array:" + sum);

}
}
