import java.util.Scanner;

class ends05 {

public static void main(String [] args){

Scanner scanner = new Scanner(System.in);

 System.out.print("Enter another string: ");

  String input = scanner.nextLine();


  if (input.endsWith("world")) {

  System.out.println("String ends with world");
  } else {
  System.out.println("String does not end with world");
   
}
}
}