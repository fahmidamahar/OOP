import java.util.Scanner;

class upper03 {

public static void main(String [] args){

Scanner scanner = new Scanner(System.in);

String[] input =  new String[5];

for(int i=0; i < input.length; i++){

System.out.print("Enter a String " + i + ":");
input[i]  = scanner.nextLine();

}
System.out.println("Uppercase Strings:");
     
for (int i = 0; i < input.length; i++){

String upper = input[i].toUpperCase();

            System.out.println(upper);
        }

        scanner.close();
}
}