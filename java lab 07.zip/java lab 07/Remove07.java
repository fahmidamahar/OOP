import java.util.Scanner;

public class Remove07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        String modified = input.replace(' ', '\0');
        System.out.println("String without spaces: " + modified.replace("\0", ""));

        scanner.close();
    }
}
