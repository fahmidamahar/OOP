import java.util.Scanner;

class index02 {
public static void main(String [] args){

 Scanner scanner  = new Scanner(System.in);

System.out.println("Enter a String");

String input = scanner.nextLine();

int index = input.indexOf("a");

System.out.println("Index a first occurrence 'a':" + index);
 
scanner.close();
}
}