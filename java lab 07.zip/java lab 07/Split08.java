import java.util.Scanner;

public class Split08 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        String[] words = input.split(" ");

        System.out.println("Words in the string:");
        int count = 0;
        for (String word : words) {
            if (!word.isEmpty()) {
                System.out.println(word);
                count++;
            }
        }

        System.out.println("Total words: " + count);

        scanner.close();
    }
}


















