import java.util.Scanner;

class start04 {

public static void main(String [] args){

Scanner scanner = new Scanner(System.in);

System.out.print("Enter a string:");

String input1 = scanner.nextLine();

if (input1.startsWith("Hello")) {

 System.out.println("String starts with Hello");
   } else {
 System.out.println("String does not start with Hello");
   }
}
}