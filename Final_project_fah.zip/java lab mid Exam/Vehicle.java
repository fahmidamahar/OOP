
class Vehicle {
    void showType() {
        System.out.println("This is a vehicle");
    }
}

class Car extends Vehicle {
    @Override
    void showType() {
        System.out.println("This is a car");
    }
}

class ElectricCar extends Car {
    @Override
    void showType() {
        System.out.println("This is an electric car");
    }
}

