public class Main {
    public static void main(String[] args) {
        Vehicle v = new Vehicle();
        v.showType(); 

        Car c = new Car();
        c.showType();

        ElectricCar eCar = new ElectricCar();
        eCar.showType(); 
    }
}

